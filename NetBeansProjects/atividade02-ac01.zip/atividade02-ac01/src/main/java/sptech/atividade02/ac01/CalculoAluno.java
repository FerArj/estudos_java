package sptech.atividade02.ac01;

public class CalculoAluno {
        
        Double calcularMedia(Double nota01, Double nota02){
        Double media = ((nota01 * 0.4) + (nota02 * 0.6));
        return media;
  }
}
